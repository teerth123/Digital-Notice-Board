package com.example.notice_board

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
